/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 475:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_server_errors_1 = __webpack_require__(397);
const mongoose_1 = __importDefault(__webpack_require__(619));
const models_1 = __webpack_require__(794);
exports.default = {
    Query: {
        kohaclub: (parent, args, { dbConn }) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                return yield models_1.KohaModel.find();
            }
            catch (error) {
                console.log("Query all clubs error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
    },
    Mutation: {
        payToClub: (parent, { _id, Amount }) => __awaiter(void 0, void 0, void 0, function* () {
            let currentAmount;
            let deductAmount;
            let newAmount;
            if (Amount < 0) {
                deductAmount = 0;
            }
            else {
                deductAmount = Amount;
            }
            console.log(deductAmount);
            try {
                const club = yield models_1.KohaModel.findById({ _id }, (err, club) => __awaiter(void 0, void 0, void 0, function* () {
                    if (err) {
                        console.log("Cannot find the club by ID error", err);
                        throw new apollo_server_errors_1.ApolloError("Cannot find the club by ID");
                    }
                    else {
                        const currentAmount = club.Amount;
                        if (Amount > currentAmount) {
                            deductAmount = Amount;
                        }
                        newAmount = currentAmount - deductAmount;
                        yield models_1.KohaModel.findByIdAndUpdate(_id, { Amount: newAmount });
                    }
                }));
                return club;
            }
            catch (error) {
                console.log("Pay to club error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
        addClub: (parent, { name }) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const newID = mongoose_1.default.Types.ObjectId();
                yield models_1.KohaModel.create({ name: name, Amount: 0, _id: newID });
                const club = yield models_1.KohaModel.findById(newID);
                return club;
            }
            catch (error) {
                console.log("Pay to club error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
    },
};


/***/ }),

/***/ 782:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_server_lambda_1 = __webpack_require__(680);
exports.default = apollo_server_lambda_1.gql `
  type Kohaclub {
    _id: ID!
    name: String!
    Amount: Int
  }
  type Query {
    kohaclub: [Kohaclub]
  }
  type Mutation {
    payToClub(_id:ID!, Amount: Int!): Kohaclub
    addClub(name: String!) : Kohaclub
  }
`;


/***/ }),

/***/ 102:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const database_1 = __webpack_require__(127);
const type_defs_1 = __importDefault(__webpack_require__(782));
const resolvers_1 = __importDefault(__webpack_require__(475));
database_1.connect();
const server = new apollo_server_lambda_1.ApolloServer({
    resolvers: resolvers_1.default,
    typeDefs: type_defs_1.default,
    playground: true,
    introspection: true,
});
exports.graphqlHandler = server.createHandler();


/***/ }),

/***/ 127:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.disconnect = exports.connect = void 0;
const mongoose_1 = __importDefault(__webpack_require__(619));
const models_1 = __webpack_require__(794);
let database;
const connect = () => {
    const uri = "mongodb+srv://gatsby:hBNWt650IxGpSDJI@cluster0.cqcjd.mongodb.net/gatsby?retryWrites=true&w=majority";
    if (database) {
        return;
    }
    mongoose_1.default.connect(uri, {
        useNewUrlParser: true,
        useFindAndModify: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
    });
    database = mongoose_1.default.connection;
    database.once("open", () => __awaiter(void 0, void 0, void 0, function* () {
        console.log("Connected to database");
    }));
    database.on("error", () => {
        console.log("Error connecting to database");
    });
    return {
        KohaModel: models_1.KohaModel,
    };
};
exports.connect = connect;
const disconnect = () => {
    if (!database) {
        return;
    }
    mongoose_1.default.disconnect();
};
exports.disconnect = disconnect;


/***/ }),

/***/ 794:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.KohaModel = void 0;
const mongoose_1 = __importDefault(__webpack_require__(619));
const kohaclubSchema = new mongoose_1.default.Schema({
    _id: { type: mongoose_1.default.SchemaTypes.ObjectId, required: true },
    name: { type: mongoose_1.default.SchemaTypes.String, required: true },
    Amount: { type: mongoose_1.default.SchemaTypes.Number, required: true },
});
exports.KohaModel = mongoose_1.default.model("KohaClub", kohaclubSchema, "kohaclub");


/***/ }),

/***/ 397:
/***/ ((module) => {

module.exports = require("apollo-server-errors");;

/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");;

/***/ }),

/***/ 619:
/***/ ((module) => {

module.exports = require("mongoose");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(102);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2hhbmRsZXIuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhLy4vc3JjL2dyYXBocWwvcmVzb2x2ZXJzLnRzIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvLi9zcmMvZ3JhcGhxbC90eXBlLWRlZnMudHMiLCJ3ZWJwYWNrOi8va2V0YS1rYWkta29oYS8uL3NyYy9oYW5kbGVyLnRzIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvLi9zcmMvbW9uZ29kYi9kYXRhYmFzZS50cyIsIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhLy4vc3JjL21vbmdvZGIvbW9kZWxzLnRzIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvZXh0ZXJuYWwgXCJhcG9sbG8tc2VydmVyLWVycm9yc1wiIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvZXh0ZXJuYWwgXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvZXh0ZXJuYWwgXCJtb25nb29zZVwiIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8va2V0YS1rYWkta29oYS93ZWJwYWNrL3N0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBvbGxvRXJyb3IgfSBmcm9tIFwiYXBvbGxvLXNlcnZlci1lcnJvcnNcIjtcbmltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIjtcbmltcG9ydCB7IElLb2hhLCBLb2hhTW9kZWwgfSBmcm9tIFwiLi4vbW9uZ29kYi9tb2RlbHNcIjtcblxuZXhwb3J0IGRlZmF1bHQge1xuICBRdWVyeToge1xuICAgIGtvaGFjbHViOiBhc3luYyAoXG4gICAgICBwYXJlbnQ6IGFueSxcbiAgICAgIGFyZ3M6IGFueSxcbiAgICAgIHsgZGJDb25uIH06IHsgZGJDb25uOiBtb25nb29zZS5Db25uZWN0aW9uIH1cbiAgICApOiBQcm9taXNlPElLb2hhW10+ID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBhd2FpdCBLb2hhTW9kZWwuZmluZCgpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJRdWVyeSBhbGwgY2x1YnMgZXJyb3I6IFwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IG5ldyBBcG9sbG9FcnJvcihcIkVycm9yIFJldHJlaXZpbmcgYWxsIGNsdWJzXCIpO1xuICAgICAgfVxuICAgIH0sXG4gIH0sXG4gIE11dGF0aW9uOiB7XG4gICAgcGF5VG9DbHViOiBhc3luYyAoXG4gICAgcGFyZW50OiBhbnksIFxuICAgIHsgX2lkLCBBbW91bnQgfTogeyBfaWQ6IElLb2hhW1wiX2lkXCJdO0Ftb3VudDogSUtvaGFbXCJBbW91bnRcIl19LCBcbiAgICApOlByb21pc2U8SUtvaGE+ID0+IHtcbiAgICAgIGxldCBjdXJyZW50QW1vdW50OiBudW1iZXI7XG4gICAgICBsZXQgZGVkdWN0QW1vdW50Om51bWJlcjtcbiAgICAgIGxldCBuZXdBbW91bnQ6IG51bWJlcjtcbiAgICAgIGlmIChBbW91bnQgPCAwKSB7XG4gICAgICAgIGRlZHVjdEFtb3VudCA9IDA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkZWR1Y3RBbW91bnQgPSBBbW91bnRcbiAgICAgIH1cbiAgICAgIGNvbnNvbGUubG9nKGRlZHVjdEFtb3VudClcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsdWI6IElLb2hhID0gYXdhaXQgS29oYU1vZGVsLmZpbmRCeUlkKHtfaWR9LCBhc3luYyhlcnI6RXJyb3IsIGNsdWI6SUtvaGEpID0+IHtcbiAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbm5vdCBmaW5kIHRoZSBjbHViIGJ5IElEIGVycm9yXCIsIGVycik7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQXBvbGxvRXJyb3IoXCJDYW5ub3QgZmluZCB0aGUgY2x1YiBieSBJRFwiKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEFtb3VudCA9IGNsdWIuQW1vdW50XG4gICAgICAgICAgICBpZiAoQW1vdW50ID4gY3VycmVudEFtb3VudCkge1xuICAgICAgICAgICAgICBkZWR1Y3RBbW91bnQgPSBBbW91bnRcbiAgICAgICAgICAgIH0gICAgICAgIFxuICAgICAgICAgICAgbmV3QW1vdW50ID0gY3VycmVudEFtb3VudCAtIGRlZHVjdEFtb3VudFxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY3VycmVudEFtb3VudClcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiZGVkdWN0IGFtb3VudFwiLCBkZWR1Y3RBbW91bnQpXG4gICAgICAgICAgICBhd2FpdCBLb2hhTW9kZWwuZmluZEJ5SWRBbmRVcGRhdGUoX2lkLCB7QW1vdW50OiBuZXdBbW91bnR9KVxuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICAgcmV0dXJuIGNsdWJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiUGF5IHRvIGNsdWIgZXJyb3I6IFwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IG5ldyBBcG9sbG9FcnJvcihcIkVycm9yIFJldHJlaXZpbmcgYWxsIGNsdWJzXCIpO1xuICAgICAgfVxuICAgIH0sXG4gICAgYWRkQ2x1YjogYXN5bmMgKFxuICAgICAgcGFyZW50OiBhbnksIFxuICAgICAgeyBuYW1lIH06IHsgbmFtZTogSUtvaGFbXCJuYW1lXCJdfSwgXG4gICAgICApOlByb21pc2U8SUtvaGE+ID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBuZXdJRCA9IG1vbmdvb3NlLlR5cGVzLk9iamVjdElkKClcbiAgICAgICAgICBhd2FpdCBLb2hhTW9kZWwuY3JlYXRlKHtuYW1lOiBuYW1lLCBBbW91bnQ6IDAsIF9pZDogbmV3SUR9KVxuICAgICAgICAgIGNvbnN0IGNsdWIgPSBhd2FpdCBLb2hhTW9kZWwuZmluZEJ5SWQobmV3SUQpXG4gICAgICAgICAgcmV0dXJuIGNsdWJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIlBheSB0byBjbHViIGVycm9yOiBcIiwgZXJyb3IpO1xuICAgICAgICAgIHRocm93IG5ldyBBcG9sbG9FcnJvcihcIkVycm9yIFJldHJlaXZpbmcgYWxsIGNsdWJzXCIpO1xuICAgICAgICB9XG4gICAgICB9LFxuICB9LFxufTtcbiIsImltcG9ydCB7IGdxbCB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuXG5leHBvcnQgZGVmYXVsdCBncWxgXG4gIHR5cGUgS29oYWNsdWIge1xuICAgIF9pZDogSUQhXG4gICAgbmFtZTogU3RyaW5nIVxuICAgIEFtb3VudDogSW50XG4gIH1cbiAgdHlwZSBRdWVyeSB7XG4gICAga29oYWNsdWI6IFtLb2hhY2x1Yl1cbiAgfVxuICB0eXBlIE11dGF0aW9uIHtcbiAgICBwYXlUb0NsdWIoX2lkOklEISwgQW1vdW50OiBJbnQhKTogS29oYWNsdWJcbiAgICBhZGRDbHViKG5hbWU6IFN0cmluZyEpIDogS29oYWNsdWJcbiAgfVxuYDtcbiIsImltcG9ydCB7IEFwb2xsb1NlcnZlciB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCIuL21vbmdvZGIvZGF0YWJhc2VcIjtcbmltcG9ydCB0eXBlRGVmcyBmcm9tIFwiLi9ncmFwaHFsL3R5cGUtZGVmc1wiO1xuaW1wb3J0IHJlc29sdmVycyBmcm9tIFwiLi9ncmFwaHFsL3Jlc29sdmVyc1wiO1xuXG4vLyBzZXJ2ZXJsZXNzIHNlcnZlciBvbiBhd3MgbGFtYmRhIC0gYXAtc291dGhlYXN0LTJcbi8vIGFzIGRlZmluZWQgaW4gc2VydmVybGVzcy55bWxcbi8vIG5lZWQgdG8gaW5zdGFsbCBhd3MtY2xpXG4vLyBydW4gYXdzIGNvbmZpZ3VyZSBmaXJzdFxuLy8gaHR0cHM6Ly9hcC1zb3V0aGVhc3QtMi5jb25zb2xlLmF3cy5hbWF6b24uY29tL2xhbWJkYS9ob21lP3JlZ2lvbj1hcC1zb3V0aGVhc3QtMiMvZGlzY292ZXJcbi8vIGZvciBsb2NhbCBkZXZlbG9wbWVudCwgcGxlYXNlIHJ1biBucG0gc3RhcnRcblxuY29ubmVjdCgpO1xuXG5jb25zdCBzZXJ2ZXIgPSBuZXcgQXBvbGxvU2VydmVyKHtcbiAgcmVzb2x2ZXJzLFxuICB0eXBlRGVmcyxcbiAgcGxheWdyb3VuZDogdHJ1ZSxcbiAgaW50cm9zcGVjdGlvbjogdHJ1ZSxcbn0pO1xuXG5cbmV4cG9ydCBjb25zdCBncmFwaHFsSGFuZGxlciA9IHNlcnZlci5jcmVhdGVIYW5kbGVyKCk7XG4iLCJpbXBvcnQgbW9uZ29vc2UgZnJvbSBcIm1vbmdvb3NlXCI7XG5pbXBvcnQgeyBLb2hhTW9kZWwgfSBmcm9tIFwiLi9tb2RlbHNcIjtcblxubGV0IGRhdGFiYXNlOiBtb25nb29zZS5Db25uZWN0aW9uO1xuXG5leHBvcnQgY29uc3QgY29ubmVjdCA9ICgpID0+IHtcbiAgY29uc3QgdXJpID1cbiAgICBcIm1vbmdvZGIrc3J2Oi8vZ2F0c2J5OmhCTld0NjUwSXhHcFNESklAY2x1c3RlcjAuY3FjamQubW9uZ29kYi5uZXQvZ2F0c2J5P3JldHJ5V3JpdGVzPXRydWUmdz1tYWpvcml0eVwiO1xuXG4gIGlmIChkYXRhYmFzZSkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIG1vbmdvb3NlLmNvbm5lY3QodXJpLCB7XG4gICAgdXNlTmV3VXJsUGFyc2VyOiB0cnVlLFxuICAgIHVzZUZpbmRBbmRNb2RpZnk6IHRydWUsXG4gICAgdXNlVW5pZmllZFRvcG9sb2d5OiB0cnVlLFxuICAgIHVzZUNyZWF0ZUluZGV4OiB0cnVlLFxuICB9KTtcblxuICBkYXRhYmFzZSA9IG1vbmdvb3NlLmNvbm5lY3Rpb247XG5cbiAgZGF0YWJhc2Uub25jZShcIm9wZW5cIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiQ29ubmVjdGVkIHRvIGRhdGFiYXNlXCIpO1xuICB9KTtcblxuICBkYXRhYmFzZS5vbihcImVycm9yXCIsICgpID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIkVycm9yIGNvbm5lY3RpbmcgdG8gZGF0YWJhc2VcIik7XG4gIH0pO1xuXG4gIHJldHVybiB7XG4gICAgS29oYU1vZGVsLFxuICB9O1xufTtcblxuZXhwb3J0IGNvbnN0IGRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gIGlmICghZGF0YWJhc2UpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBtb25nb29zZS5kaXNjb25uZWN0KCk7XG59O1xuIiwiaW1wb3J0IG1vbmdvb3NlLCB7IERvY3VtZW50LCBNb2RlbCB9IGZyb20gXCJtb25nb29zZVwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIElLb2hhIGV4dGVuZHMgbW9uZ29vc2UuRG9jdW1lbnQge1xuICBfaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBBbW91bnQ6IG51bWJlcjtcbn1cblxuY29uc3Qga29oYWNsdWJTY2hlbWE6IG1vbmdvb3NlLlNjaGVtYSA9IG5ldyBtb25nb29zZS5TY2hlbWEoe1xuICBfaWQ6IHsgdHlwZTogbW9uZ29vc2UuU2NoZW1hVHlwZXMuT2JqZWN0SWQsIHJlcXVpcmVkOiB0cnVlIH0sXG4gIG5hbWU6IHsgdHlwZTogbW9uZ29vc2UuU2NoZW1hVHlwZXMuU3RyaW5nLCByZXF1aXJlZDogdHJ1ZSB9LFxuICBBbW91bnQ6IHsgdHlwZTogbW9uZ29vc2UuU2NoZW1hVHlwZXMuTnVtYmVyLCByZXF1aXJlZDogdHJ1ZSB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCBLb2hhTW9kZWw6IG1vbmdvb3NlLk1vZGVsPElLb2hhPiA9IG1vbmdvb3NlLm1vZGVsKFxuICBcIktvaGFDbHViXCIsXG4gIGtvaGFjbHViU2NoZW1hLFxuICBcImtvaGFjbHViXCJcbik7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tc2VydmVyLWVycm9yc1wiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm1vbmdvb3NlXCIpOzsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBpcyByZWZlcmVuY2VkIGJ5IG90aGVyIG1vZHVsZXMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDEwMik7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUtBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QTs7Ozs7OztBQ3hFQTtBQUVBOzs7Ozs7Ozs7Ozs7O0FBYUE7QUFDQTtBQUNBO0E7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBU0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QkE7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUE1QkE7QUE4QkE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBTkE7QUFDQTtBQUNBO0E7Ozs7Ozs7Ozs7O0FDckNBO0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBOzs7OztBQ2hCQTtBQUNBO0E7Ozs7O0FDREE7QUFDQTtBOzs7OztBQ0RBO0FBQ0E7QTs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7QSIsInNvdXJjZVJvb3QiOiIifQ==