/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 279:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.enviroment = void 0;
const dotenv_1 = __importDefault(__webpack_require__(334));
dotenv_1.default.config();
exports.enviroment = {
    mongoURL: process.env.MONGO_URL,
};


/***/ }),

/***/ 475:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_server_errors_1 = __webpack_require__(397);
const mongoose_1 = __importDefault(__webpack_require__(619));
const models_1 = __webpack_require__(794);
exports.default = {
    Query: {
        kohaclub: (parent, args) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                return yield models_1.KohaModel.find();
            }
            catch (error) {
                console.log("Query all clubs error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
        listAllTransactions: (parent, args) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                return yield models_1.TransactionsModel.find();
                models_1.TransactionsModel.aggregate();
            }
            catch (error) {
                console.log("Query all clubs error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
        listTransactionByClubId: (parent, { clubId }) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                return yield models_1.TransactionsModel.find({ clubId: clubId });
            }
            catch (error) {
                console.log("Query all clubs error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
    },
    Mutation: {
        payToClubById: (parent, { _id, Amount }) => __awaiter(void 0, void 0, void 0, function* () {
            let currentAmount;
            let deductAmount;
            let newAmount;
            if (Amount < 0) {
                deductAmount = 0;
            }
            else {
                deductAmount = Amount;
            }
            console.log(deductAmount);
            try {
                const club = yield models_1.KohaModel.findById({ _id }, (err, club) => __awaiter(void 0, void 0, void 0, function* () {
                    if (err) {
                        console.log("Cannot find the club by ID error", err);
                        throw new apollo_server_errors_1.ApolloError("Cannot find the club by ID");
                    }
                    else {
                        currentAmount = club.Amount;
                        if (Amount > currentAmount) {
                            deductAmount = Amount;
                        }
                        newAmount = currentAmount - deductAmount;
                        yield models_1.KohaModel.findByIdAndUpdate(_id, { Amount: newAmount });
                    }
                }));
                return club;
            }
            catch (error) {
                console.log("Pay to club error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
        payToClubById10: (parent, { _id }) => __awaiter(void 0, void 0, void 0, function* () {
            let currentAmount;
            let newAmount;
            try {
                const club = yield models_1.KohaModel.findById({ _id }, (err, club) => __awaiter(void 0, void 0, void 0, function* () {
                    if (err) {
                        console.log("Cannot find the club by Name error", err);
                        throw new apollo_server_errors_1.ApolloError("Cannot find the club by Name");
                    }
                    else {
                        currentAmount = club.Amount;
                        newAmount = currentAmount - 10;
                        yield models_1.KohaModel.findByIdAndUpdate(_id, { Amount: newAmount });
                        const newID = mongoose_1.default.Types.ObjectId();
                        yield models_1.TransactionsModel.create({
                            _id: newID,
                            clubId: _id,
                            amount: 10,
                        });
                    }
                }));
                return club;
            }
            catch (error) {
                console.log("Pay to club error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
        addClub: (parent, { name }) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const newID = mongoose_1.default.Types.ObjectId();
                yield models_1.KohaModel.create({ name: name, Amount: 0, _id: newID });
                const club = yield models_1.KohaModel.findById(newID);
                return club;
            }
            catch (error) {
                console.log("Pay to club error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Retreiving all clubs");
            }
        }),
        deleteTrnx: (parent, { _id }) => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const transaction = models_1.TransactionsModel.findOne({ _id: _id });
                yield models_1.TransactionsModel.deleteOne({ _id: _id });
                return transaction;
            }
            catch (error) {
                console.log("Delete to transaction error: ", error);
                throw new apollo_server_errors_1.ApolloError("Error Delete transaction ");
            }
        }),
    },
};


/***/ }),

/***/ 782:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const apollo_server_lambda_1 = __webpack_require__(680);
exports.default = apollo_server_lambda_1.gql `
  type Kohaclub {
    _id: ID
    name: String
    Amount: Int
  }
  type Query {
    kohaclub: [Kohaclub]
    listTransactionByClubId(clubId: String): [Transactions]
    listAllTransactions: [Transactions]
  }
  type Mutation {
    payToClubById(_id: ID!, Amount: Int!): Kohaclub
    payToClubById10(_id: ID!): Kohaclub
    addClub(name: String!): Kohaclub
    deleteTrnx(_id: ID): Transactions
  }

  scalar DateTime

  type Transactions {
    _id: ID
    clubId: String
    date: DateTime
    amount: Int
  }
`;


/***/ }),

/***/ 102:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const database_1 = __webpack_require__(127);
const type_defs_1 = __importDefault(__webpack_require__(782));
const resolvers_1 = __importDefault(__webpack_require__(475));
database_1.connect();
const server = new apollo_server_lambda_1.ApolloServer({
    resolvers: resolvers_1.default,
    typeDefs: type_defs_1.default,
    playground: true,
    introspection: true,
});
exports.graphqlHandler = server.createHandler({
    cors: {
        origin: "*",
        credentials: false,
    },
});


/***/ }),

/***/ 127:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.disconnect = exports.connect = void 0;
const mongoose_1 = __importDefault(__webpack_require__(619));
const enviroment_1 = __webpack_require__(279);
const models_1 = __webpack_require__(794);
let database;
const connect = () => {
    const uri = enviroment_1.enviroment.mongoURL;
    if (database) {
        return;
    }
    mongoose_1.default.connect(uri, {
        useNewUrlParser: true,
        useFindAndModify: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
    });
    database = mongoose_1.default.connection;
    database.once("open", () => __awaiter(void 0, void 0, void 0, function* () {
        console.log("Connected to database");
    }));
    database.on("error", () => {
        console.log("Error connecting to database");
    });
    return {
        KohaModel: models_1.KohaModel,
        TransactionsModel: models_1.TransactionsModel,
    };
};
exports.connect = connect;
const disconnect = () => {
    if (!database) {
        return;
    }
    mongoose_1.default.disconnect();
};
exports.disconnect = disconnect;


/***/ }),

/***/ 794:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TransactionsModel = exports.KohaModel = void 0;
const mongoose_1 = __importDefault(__webpack_require__(619));
const kohaclubSchema = new mongoose_1.default.Schema({
    _id: { type: mongoose_1.default.SchemaTypes.ObjectId },
    name: { type: mongoose_1.default.SchemaTypes.String },
    Amount: { type: mongoose_1.default.SchemaTypes.Number },
});
exports.KohaModel = mongoose_1.default.model("KohaClub", kohaclubSchema, "kohaclub");
const TransactionsSchema = new mongoose_1.default.Schema({
    _id: { type: mongoose_1.default.SchemaTypes.ObjectId },
    clubId: { type: mongoose_1.default.SchemaTypes.String },
    date: { type: mongoose_1.default.SchemaTypes.Date, default: Date.now },
    amount: { type: mongoose_1.default.SchemaTypes.Number },
});
exports.TransactionsModel = mongoose_1.default.model("transactions", TransactionsSchema, "transactions");


/***/ }),

/***/ 397:
/***/ ((module) => {

module.exports = require("apollo-server-errors");;

/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");;

/***/ }),

/***/ 334:
/***/ ((module) => {

module.exports = require("dotenv");;

/***/ }),

/***/ 619:
/***/ ((module) => {

module.exports = require("mongoose");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(102);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2hhbmRsZXIuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhLy4vZW52aXJvbWVudC50cyIsIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhLy4vc3JjL2dyYXBocWwvcmVzb2x2ZXJzLnRzIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvLi9zcmMvZ3JhcGhxbC90eXBlLWRlZnMudHMiLCJ3ZWJwYWNrOi8va2V0YS1rYWkta29oYS8uL3NyYy9oYW5kbGVyLnRzIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvLi9zcmMvbW9uZ29kYi9kYXRhYmFzZS50cyIsIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhLy4vc3JjL21vbmdvZGIvbW9kZWxzLnRzIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvZXh0ZXJuYWwgXCJhcG9sbG8tc2VydmVyLWVycm9yc1wiIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvZXh0ZXJuYWwgXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvZXh0ZXJuYWwgXCJkb3RlbnZcIiIsIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhL2V4dGVybmFsIFwibW9uZ29vc2VcIiIsIndlYnBhY2s6Ly9rZXRhLWthaS1rb2hhL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2tldGEta2FpLWtvaGEvd2VicGFjay9zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBkb3RlbnYgZnJvbSBcImRvdGVudlwiO1xuXG5kb3RlbnYuY29uZmlnKCk7XG5cbnR5cGUgRW52aXJvbWVudCA9IHtcbiAgbW9uZ29VUkw6IHN0cmluZztcbn07XG5cbmV4cG9ydCBjb25zdCBlbnZpcm9tZW50OiBFbnZpcm9tZW50ID0ge1xuICBtb25nb1VSTDogcHJvY2Vzcy5lbnYuTU9OR09fVVJMIGFzIHN0cmluZyxcbn07XG4iLCJpbXBvcnQgeyBBcG9sbG9FcnJvciB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWVycm9yc1wiO1xuaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xuaW1wb3J0IHtcbiAgSUtvaGEsXG4gIEtvaGFNb2RlbCxcbiAgSVRyYXNhY3Rpb25zLFxuICBUcmFuc2FjdGlvbnNNb2RlbCxcbn0gZnJvbSBcIi4uL21vbmdvZGIvbW9kZWxzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgUXVlcnk6IHtcbiAgICBrb2hhY2x1YjogYXN5bmMgKHBhcmVudDogYW55LCBhcmdzOiBhbnkpOiBQcm9taXNlPElLb2hhW10+ID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBhd2FpdCBLb2hhTW9kZWwuZmluZCgpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJRdWVyeSBhbGwgY2x1YnMgZXJyb3I6IFwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IG5ldyBBcG9sbG9FcnJvcihcIkVycm9yIFJldHJlaXZpbmcgYWxsIGNsdWJzXCIpO1xuICAgICAgfVxuICAgIH0sXG4gICAgbGlzdEFsbFRyYW5zYWN0aW9uczogYXN5bmMgKFxuICAgICAgcGFyZW50OiBhbnksXG4gICAgICBhcmdzOiBhbnlcbiAgICApOiBQcm9taXNlPElUcmFzYWN0aW9uc1tdPiA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgVHJhbnNhY3Rpb25zTW9kZWwuZmluZCgpO1xuICAgICAgICBUcmFuc2FjdGlvbnNNb2RlbC5hZ2dyZWdhdGUoKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiUXVlcnkgYWxsIGNsdWJzIGVycm9yOiBcIiwgZXJyb3IpO1xuICAgICAgICB0aHJvdyBuZXcgQXBvbGxvRXJyb3IoXCJFcnJvciBSZXRyZWl2aW5nIGFsbCBjbHVic1wiKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGxpc3RUcmFuc2FjdGlvbkJ5Q2x1YklkOiBhc3luYyAoXG4gICAgICBwYXJlbnQ6IGFueSxcbiAgICAgIHsgY2x1YklkIH06IHsgY2x1YklkOiBJVHJhc2FjdGlvbnNbXCJjbHViSWRcIl0gfVxuICAgICk6IFByb21pc2U8SVRyYXNhY3Rpb25zW10+ID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBhd2FpdCBUcmFuc2FjdGlvbnNNb2RlbC5maW5kKHsgY2x1YklkOiBjbHViSWQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmxvZyhcIlF1ZXJ5IGFsbCBjbHVicyBlcnJvcjogXCIsIGVycm9yKTtcbiAgICAgICAgdGhyb3cgbmV3IEFwb2xsb0Vycm9yKFwiRXJyb3IgUmV0cmVpdmluZyBhbGwgY2x1YnNcIik7XG4gICAgICB9XG4gICAgfSxcbiAgfSxcbiAgTXV0YXRpb246IHtcbiAgICBwYXlUb0NsdWJCeUlkOiBhc3luYyAoXG4gICAgICBwYXJlbnQ6IGFueSxcbiAgICAgIHsgX2lkLCBBbW91bnQgfTogeyBfaWQ6IElLb2hhW1wiX2lkXCJdOyBBbW91bnQ6IElLb2hhW1wiQW1vdW50XCJdIH1cbiAgICApOiBQcm9taXNlPElLb2hhPiA9PiB7XG4gICAgICBsZXQgY3VycmVudEFtb3VudDogbnVtYmVyO1xuICAgICAgbGV0IGRlZHVjdEFtb3VudDogbnVtYmVyO1xuICAgICAgbGV0IG5ld0Ftb3VudDogbnVtYmVyO1xuICAgICAgaWYgKEFtb3VudCA8IDApIHtcbiAgICAgICAgZGVkdWN0QW1vdW50ID0gMDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRlZHVjdEFtb3VudCA9IEFtb3VudDtcbiAgICAgIH1cbiAgICAgIGNvbnNvbGUubG9nKGRlZHVjdEFtb3VudCk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbHViOiBJS29oYSA9IGF3YWl0IEtvaGFNb2RlbC5maW5kQnlJZChcbiAgICAgICAgICB7IF9pZCB9LFxuICAgICAgICAgIGFzeW5jIChlcnI6IEVycm9yLCBjbHViOiBJS29oYSkgPT4ge1xuICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbm5vdCBmaW5kIHRoZSBjbHViIGJ5IElEIGVycm9yXCIsIGVycik7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBBcG9sbG9FcnJvcihcIkNhbm5vdCBmaW5kIHRoZSBjbHViIGJ5IElEXCIpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY3VycmVudEFtb3VudCA9IGNsdWIuQW1vdW50O1xuICAgICAgICAgICAgICBpZiAoQW1vdW50ID4gY3VycmVudEFtb3VudCkge1xuICAgICAgICAgICAgICAgIGRlZHVjdEFtb3VudCA9IEFtb3VudDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBuZXdBbW91bnQgPSBjdXJyZW50QW1vdW50IC0gZGVkdWN0QW1vdW50O1xuICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjdXJyZW50QW1vdW50KVxuICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcImRlZHVjdCBhbW91bnRcIiwgZGVkdWN0QW1vdW50KVxuICAgICAgICAgICAgICBhd2FpdCBLb2hhTW9kZWwuZmluZEJ5SWRBbmRVcGRhdGUoX2lkLCB7IEFtb3VudDogbmV3QW1vdW50IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIGNsdWI7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmxvZyhcIlBheSB0byBjbHViIGVycm9yOiBcIiwgZXJyb3IpO1xuICAgICAgICB0aHJvdyBuZXcgQXBvbGxvRXJyb3IoXCJFcnJvciBSZXRyZWl2aW5nIGFsbCBjbHVic1wiKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHBheVRvQ2x1YkJ5SWQxMDogYXN5bmMgKFxuICAgICAgcGFyZW50OiBhbnksXG4gICAgICB7IF9pZCB9OiB7IF9pZDogSUtvaGFbXCJfaWRcIl0gfVxuICAgICk6IFByb21pc2U8SUtvaGE+ID0+IHtcbiAgICAgIGxldCBjdXJyZW50QW1vdW50OiBudW1iZXI7XG4gICAgICBsZXQgbmV3QW1vdW50OiBudW1iZXI7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbHViOiBJS29oYSA9IGF3YWl0IEtvaGFNb2RlbC5maW5kQnlJZChcbiAgICAgICAgICB7IF9pZCB9LFxuICAgICAgICAgIGFzeW5jIChlcnI6IEVycm9yLCBjbHViOiBJS29oYSkgPT4ge1xuICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNhbm5vdCBmaW5kIHRoZSBjbHViIGJ5IE5hbWUgZXJyb3JcIiwgZXJyKTtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEFwb2xsb0Vycm9yKFwiQ2Fubm90IGZpbmQgdGhlIGNsdWIgYnkgTmFtZVwiKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGN1cnJlbnRBbW91bnQgPSBjbHViLkFtb3VudDtcbiAgICAgICAgICAgICAgbmV3QW1vdW50ID0gY3VycmVudEFtb3VudCAtIDEwO1xuICAgICAgICAgICAgICBhd2FpdCBLb2hhTW9kZWwuZmluZEJ5SWRBbmRVcGRhdGUoX2lkLCB7IEFtb3VudDogbmV3QW1vdW50IH0pO1xuICAgICAgICAgICAgICBjb25zdCBuZXdJRCA9IG1vbmdvb3NlLlR5cGVzLk9iamVjdElkKCk7XG4gICAgICAgICAgICAgIGF3YWl0IFRyYW5zYWN0aW9uc01vZGVsLmNyZWF0ZSh7XG4gICAgICAgICAgICAgICAgX2lkOiBuZXdJRCxcbiAgICAgICAgICAgICAgICBjbHViSWQ6IF9pZCxcbiAgICAgICAgICAgICAgICBhbW91bnQ6IDEwLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiBjbHViO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJQYXkgdG8gY2x1YiBlcnJvcjogXCIsIGVycm9yKTtcbiAgICAgICAgdGhyb3cgbmV3IEFwb2xsb0Vycm9yKFwiRXJyb3IgUmV0cmVpdmluZyBhbGwgY2x1YnNcIik7XG4gICAgICB9XG4gICAgfSxcbiAgICBhZGRDbHViOiBhc3luYyAoXG4gICAgICBwYXJlbnQ6IGFueSxcbiAgICAgIHsgbmFtZSB9OiB7IG5hbWU6IElLb2hhW1wibmFtZVwiXSB9XG4gICAgKTogUHJvbWlzZTxJS29oYT4gPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgbmV3SUQgPSBtb25nb29zZS5UeXBlcy5PYmplY3RJZCgpO1xuICAgICAgICBhd2FpdCBLb2hhTW9kZWwuY3JlYXRlKHsgbmFtZTogbmFtZSwgQW1vdW50OiAwLCBfaWQ6IG5ld0lEIH0pO1xuICAgICAgICBjb25zdCBjbHViID0gYXdhaXQgS29oYU1vZGVsLmZpbmRCeUlkKG5ld0lEKTtcbiAgICAgICAgcmV0dXJuIGNsdWI7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmxvZyhcIlBheSB0byBjbHViIGVycm9yOiBcIiwgZXJyb3IpO1xuICAgICAgICB0aHJvdyBuZXcgQXBvbGxvRXJyb3IoXCJFcnJvciBSZXRyZWl2aW5nIGFsbCBjbHVic1wiKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGRlbGV0ZVRybng6IGFzeW5jIChcbiAgICAgIHBhcmVudDogYW55LFxuICAgICAgeyBfaWQgfTogeyBfaWQ6IElUcmFzYWN0aW9uc1tcIl9pZFwiXSB9XG4gICAgKTogUHJvbWlzZTxJVHJhc2FjdGlvbnM+ID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRyYW5zYWN0aW9uID0gVHJhbnNhY3Rpb25zTW9kZWwuZmluZE9uZSh7IF9pZDogX2lkIH0pO1xuICAgICAgICBhd2FpdCBUcmFuc2FjdGlvbnNNb2RlbC5kZWxldGVPbmUoeyBfaWQ6IF9pZCB9KTtcbiAgICAgICAgcmV0dXJuIHRyYW5zYWN0aW9uO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEZWxldGUgdG8gdHJhbnNhY3Rpb24gZXJyb3I6IFwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IG5ldyBBcG9sbG9FcnJvcihcIkVycm9yIERlbGV0ZSB0cmFuc2FjdGlvbiBcIik7XG4gICAgICB9XG4gICAgfSxcbiAgfSxcbn07XG4iLCJpbXBvcnQgeyBncWwgfSBmcm9tIFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIjtcblxuZXhwb3J0IGRlZmF1bHQgZ3FsYFxuICB0eXBlIEtvaGFjbHViIHtcbiAgICBfaWQ6IElEXG4gICAgbmFtZTogU3RyaW5nXG4gICAgQW1vdW50OiBJbnRcbiAgfVxuICB0eXBlIFF1ZXJ5IHtcbiAgICBrb2hhY2x1YjogW0tvaGFjbHViXVxuICAgIGxpc3RUcmFuc2FjdGlvbkJ5Q2x1YklkKGNsdWJJZDogU3RyaW5nKTogW1RyYW5zYWN0aW9uc11cbiAgICBsaXN0QWxsVHJhbnNhY3Rpb25zOiBbVHJhbnNhY3Rpb25zXVxuICB9XG4gIHR5cGUgTXV0YXRpb24ge1xuICAgIHBheVRvQ2x1YkJ5SWQoX2lkOiBJRCEsIEFtb3VudDogSW50ISk6IEtvaGFjbHViXG4gICAgcGF5VG9DbHViQnlJZDEwKF9pZDogSUQhKTogS29oYWNsdWJcbiAgICBhZGRDbHViKG5hbWU6IFN0cmluZyEpOiBLb2hhY2x1YlxuICAgIGRlbGV0ZVRybngoX2lkOiBJRCk6IFRyYW5zYWN0aW9uc1xuICB9XG5cbiAgc2NhbGFyIERhdGVUaW1lXG5cbiAgdHlwZSBUcmFuc2FjdGlvbnMge1xuICAgIF9pZDogSURcbiAgICBjbHViSWQ6IFN0cmluZ1xuICAgIGRhdGU6IERhdGVUaW1lXG4gICAgYW1vdW50OiBJbnRcbiAgfVxuYDtcbiIsImltcG9ydCB7IEFwb2xsb1NlcnZlciB9IGZyb20gXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCIuL21vbmdvZGIvZGF0YWJhc2VcIjtcbmltcG9ydCB0eXBlRGVmcyBmcm9tIFwiLi9ncmFwaHFsL3R5cGUtZGVmc1wiO1xuaW1wb3J0IHJlc29sdmVycyBmcm9tIFwiLi9ncmFwaHFsL3Jlc29sdmVyc1wiO1xuXG4vLyBzZXJ2ZXJsZXNzIHNlcnZlciBvbiBhd3MgbGFtYmRhIC0gYXAtc291dGhlYXN0LTJcbi8vIGFzIGRlZmluZWQgaW4gc2VydmVybGVzcy55bWxcbi8vIG5lZWQgdG8gaW5zdGFsbCBhd3MtY2xpXG4vLyBydW4gYXdzIGNvbmZpZ3VyZSBmaXJzdFxuLy8gaHR0cHM6Ly9hcC1zb3V0aGVhc3QtMi5jb25zb2xlLmF3cy5hbWF6b24uY29tL2xhbWJkYS9ob21lP3JlZ2lvbj1hcC1zb3V0aGVhc3QtMiMvZGlzY292ZXJcbi8vIGZvciBsb2NhbCBkZXZlbG9wbWVudCwgcGxlYXNlIHJ1biBucG0gc3RhcnRcblxuLy8gY29ubmVjdCB0byBtb25nZG9EQlxuY29ubmVjdCgpO1xuXG5jb25zdCBzZXJ2ZXIgPSBuZXcgQXBvbGxvU2VydmVyKHtcbiAgcmVzb2x2ZXJzLFxuICB0eXBlRGVmcyxcbiAgcGxheWdyb3VuZDogdHJ1ZSxcbiAgaW50cm9zcGVjdGlvbjogdHJ1ZSxcbn0pO1xuXG5leHBvcnQgY29uc3QgZ3JhcGhxbEhhbmRsZXIgPSBzZXJ2ZXIuY3JlYXRlSGFuZGxlcih7XG4gIGNvcnM6IHtcbiAgICBvcmlnaW46IFwiKlwiLFxuICAgIGNyZWRlbnRpYWxzOiBmYWxzZSxcbiAgfSxcbn0pO1xuIiwiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xuaW1wb3J0IHsgZW52aXJvbWVudCB9IGZyb20gXCIuLi8uLi9lbnZpcm9tZW50XCI7XG5pbXBvcnQgeyBLb2hhTW9kZWwsIFRyYW5zYWN0aW9uc01vZGVsIH0gZnJvbSBcIi4vbW9kZWxzXCI7XG5cbmxldCBkYXRhYmFzZTogbW9uZ29vc2UuQ29ubmVjdGlvbjtcblxuZXhwb3J0IGNvbnN0IGNvbm5lY3QgPSAoKSA9PiB7XG4gIGNvbnN0IHVyaSA9IGVudmlyb21lbnQubW9uZ29VUkw7XG5cbiAgaWYgKGRhdGFiYXNlKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgbW9uZ29vc2UuY29ubmVjdCh1cmksIHtcbiAgICB1c2VOZXdVcmxQYXJzZXI6IHRydWUsXG4gICAgdXNlRmluZEFuZE1vZGlmeTogdHJ1ZSxcbiAgICB1c2VVbmlmaWVkVG9wb2xvZ3k6IHRydWUsXG4gICAgdXNlQ3JlYXRlSW5kZXg6IHRydWUsXG4gIH0pO1xuXG4gIGRhdGFiYXNlID0gbW9uZ29vc2UuY29ubmVjdGlvbjtcblxuICBkYXRhYmFzZS5vbmNlKFwib3BlblwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJDb25uZWN0ZWQgdG8gZGF0YWJhc2VcIik7XG4gIH0pO1xuXG4gIGRhdGFiYXNlLm9uKFwiZXJyb3JcIiwgKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgY29ubmVjdGluZyB0byBkYXRhYmFzZVwiKTtcbiAgfSk7XG5cbiAgcmV0dXJuIHtcbiAgICBLb2hhTW9kZWwsXG4gICAgVHJhbnNhY3Rpb25zTW9kZWwsXG4gIH07XG59O1xuXG5leHBvcnQgY29uc3QgZGlzY29ubmVjdCA9ICgpID0+IHtcbiAgaWYgKCFkYXRhYmFzZSkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIG1vbmdvb3NlLmRpc2Nvbm5lY3QoKTtcbn07XG4iLCJpbXBvcnQgbW9uZ29vc2UsIHsgRGF0ZSwgRG9jdW1lbnQsIE1vZGVsIH0gZnJvbSBcIm1vbmdvb3NlXCI7XG5cbi8vIEtvaGEgQ2x1YnMgVGFibGUgTW9kZWxsaW5nXG5leHBvcnQgaW50ZXJmYWNlIElLb2hhIGV4dGVuZHMgbW9uZ29vc2UuRG9jdW1lbnQge1xuICBfaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBBbW91bnQ6IG51bWJlcjtcbn1cblxuY29uc3Qga29oYWNsdWJTY2hlbWE6IG1vbmdvb3NlLlNjaGVtYSA9IG5ldyBtb25nb29zZS5TY2hlbWEoe1xuICBfaWQ6IHsgdHlwZTogbW9uZ29vc2UuU2NoZW1hVHlwZXMuT2JqZWN0SWQgfSxcbiAgbmFtZTogeyB0eXBlOiBtb25nb29zZS5TY2hlbWFUeXBlcy5TdHJpbmcgfSxcbiAgQW1vdW50OiB7IHR5cGU6IG1vbmdvb3NlLlNjaGVtYVR5cGVzLk51bWJlciB9LFxufSk7XG5cbi8vIGxpbmsgdG8gZXhpc3RpbmcgY29sbGVjdGlvbiBvbiBtb25nb2RiXG5leHBvcnQgY29uc3QgS29oYU1vZGVsOiBtb25nb29zZS5Nb2RlbDxJS29oYT4gPSBtb25nb29zZS5tb2RlbChcbiAgXCJLb2hhQ2x1YlwiLFxuICBrb2hhY2x1YlNjaGVtYSxcbiAgXCJrb2hhY2x1YlwiXG4pO1xuXG4vLyBUcmFuc2FjdGlvbiBUYWJsZSBNb2RlbGxpbmdcbmV4cG9ydCBpbnRlcmZhY2UgSVRyYXNhY3Rpb25zIGV4dGVuZHMgbW9uZ29vc2UuRG9jdW1lbnQge1xuICBfaWQ6IHN0cmluZztcbiAgY2x1YklkOiBzdHJpbmc7XG4gIGRhdGU6IERhdGU7XG4gIGFtb3VudDogbnVtYmVyO1xufVxuXG5jb25zdCBUcmFuc2FjdGlvbnNTY2hlbWE6IG1vbmdvb3NlLlNjaGVtYSA9IG5ldyBtb25nb29zZS5TY2hlbWEoe1xuICBfaWQ6IHsgdHlwZTogbW9uZ29vc2UuU2NoZW1hVHlwZXMuT2JqZWN0SWQgfSxcbiAgY2x1YklkOiB7IHR5cGU6IG1vbmdvb3NlLlNjaGVtYVR5cGVzLlN0cmluZyB9LFxuICBkYXRlOiB7IHR5cGU6IG1vbmdvb3NlLlNjaGVtYVR5cGVzLkRhdGUsIGRlZmF1bHQ6IERhdGUubm93IH0sXG4gIGFtb3VudDogeyB0eXBlOiBtb25nb29zZS5TY2hlbWFUeXBlcy5OdW1iZXIgfSxcbn0pO1xuXG4vLyBsaW5rIHRvIGV4aXN0aW5nIGNvbGxlY3Rpb24gb24gbW9uZ29kYlxuZXhwb3J0IGNvbnN0IFRyYW5zYWN0aW9uc01vZGVsOiBtb25nb29zZS5Nb2RlbDxJVHJhc2FjdGlvbnM+ID0gbW9uZ29vc2UubW9kZWwoXG4gIFwidHJhbnNhY3Rpb25zXCIsXG4gIFRyYW5zYWN0aW9uc1NjaGVtYSxcbiAgXCJ0cmFuc2FjdGlvbnNcIlxuKTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1zZXJ2ZXItZXJyb3JzXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZG90ZW52XCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJtb25nb29zZVwiKTs7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXygxMDIpO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFFQTtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFDQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBOzs7Ozs7O0FDaEpBO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBMEJBO0FBQ0E7QUFDQTtBOzs7Ozs7Ozs7OztBQzlCQTtBQUNBO0FBQ0E7QUFDQTtBQVVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdCQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE1QkE7QUE4QkE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBTkE7QUFDQTtBQUNBO0E7Ozs7Ozs7Ozs7O0FDdENBO0FBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBY0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0E7Ozs7O0FDeENBO0FBQ0E7QTs7Ozs7QUNEQTtBQUNBO0E7Ozs7O0FDREE7QUFDQTtBOzs7OztBQ0RBO0FBQ0E7QTs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7QSIsInNvdXJjZVJvb3QiOiIifQ==